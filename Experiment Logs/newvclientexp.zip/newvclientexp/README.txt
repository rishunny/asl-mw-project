
Filename -> [Number of threads, Number of servers, Number of virtual clients, Number of client machines, configuration file, replication factor]

x= {0,1,2,3,4,5,6,7,8} 

exp_0_iter_x -> [16, 5, 2, 3, "custom_config.cfg", 1],
exp_1_iter_x -> [16, 5, 4, 3, "custom_config.cfg", 1],
exp_2_iter_x -> [16, 5, 8, 3, "custom_config.cfg", 1],
exp_3_iter_x -> [16, 5, 16, 3, "custom_config.cfg", 1],
exp_4_iter_x -> [16, 5, 24, 3, "custom_config.cfg", 1]


custom_config.cfg = Key 16B, Value 128B, 0% writes, 100% reads


