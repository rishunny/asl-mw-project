
Filename -> [Number of threads, Number of servers, Number of virtual clients, Number of client machines, configuration file, replication factor]

x= {0,1,2,3,4} 
exp_0_iter_x -> [16, 3, 80, 3, "smallvalue5.cfg", 1]
exp_1_iter_x -> [16, 3, 80, 3, "smallvalue5.cfg", 3]
exp_2_iter_x -> [16, 3, 80, 3, "smallvalue5.cfg", 2]
exp_3_iter_x -> [16, 5, 80, 3, "smallvalue5.cfg", 1]
exp_4_iter_x -> [16, 5, 80, 3, "smallvalue5.cfg", 5]
exp_5_iter_x -> [16, 5, 80, 3, "smallvalue5.cfg", 3]
exp_6_iter_x -> [16, 7, 80, 3, "smallvalue5.cfg", 1]
exp_7_iter_x -> [16, 7, 80, 3, "smallvalue5.cfg", 7]
exp_8_iter_x -> [16, 7, 80, 3, "smallvalue5.cfg", 4]

smallvalue5.cfg = 5% writes
