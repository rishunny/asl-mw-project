
Filename -> [Number of threads, Number of servers, Number of virtual clients, Number of client machines, configuration file, replication factor]

x= {0,1,2,3,4} 
exp_0_iter_x -> [16, 5, 32, 3, "smallvalue.cfg", 5]
exp_1_iter_x -> [16, 5, 32, 3, "smallvalue10.cfg", 5]
exp_2_iter_x -> [16, 5, 32, 3, "largevalue.cfg", 5]
exp_3_iter_x -> [16, 5, 32, 3, "largevalue10.cfg", 5]
exp_4_iter_x -> [16, 5, 96, 3, "smallvalue.cfg", 5]
exp_5_iter_x -> [16, 5, 96, 3, "smallvalue10.cfg", 5]
exp_6_iter_x -> [16, 5, 96, 3, "largevalue.cfg", 5]
exp_7_iter_x -> [16, 5, 96, 3, "largevalue10.cfg", 5]

smallvalue.cfg = Key 16B, Value 128B, 1% writes
smallvalue10.cfg = Key 16B, Value 128B, 10% writes
largevalue.cfg = Key 16B, Value 512B, 1% writes
largevalue10.cfg = Key 16B, Value 512B, 10% writes


